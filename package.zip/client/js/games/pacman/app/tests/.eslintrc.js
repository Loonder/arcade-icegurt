// TODO: Remove this and fix the errors
module.exports = {
  "rules": {
    "no-multi-assign": "off"
  }
};